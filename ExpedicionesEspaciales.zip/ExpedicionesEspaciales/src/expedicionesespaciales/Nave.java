
package expedicionesespaciales;

import java.util.Objects;


public abstract class Nave {
    private String nombre;
    private int capacidad;
    private int anioLanzamiento;

    public Nave(String nombre, int capacidad, int anioLanzamiento) {
        this.nombre = nombre;
        this.capacidad = capacidad;
        this.anioLanzamiento = anioLanzamiento;
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        Nave other = (Nave) o;

        return other.anioLanzamiento == anioLanzamiento
                && other.nombre.equals(nombre);
    }
    
    @Override
    public int hashCode(){
        return Objects.hash(anioLanzamiento, nombre);
    }
    
    protected String getNombre(){
        return nombre;
    }
    
    @Override
    public String toString(){
        return  nombre + " capacidad de tripulacion: " + capacidad + " Anio Lanzamiento: " + anioLanzamiento;
    }
    
}
