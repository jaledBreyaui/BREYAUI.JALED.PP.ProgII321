
package expedicionesespaciales;

public class NaveExploracion extends Nave implements Explorar{
    private TipoMision tipoMision;
    
    public NaveExploracion(String nombre, int capacidad, int anioLanzamiento, TipoMision tipoMision) {
        super(nombre, capacidad, anioLanzamiento);
        this.tipoMision = tipoMision;
    }
    
    
    @Override
    public void explorar() {
        System.out.println("Explorando con la Nave de exploracion " + getNombre());
    }
    
    @Override
    public String toString(){
        return super.toString() + " Tipo de mision: " + tipoMision;
    }
}
