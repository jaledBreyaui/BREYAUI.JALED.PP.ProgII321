
package expedicionesespaciales;

public class Carguero extends Nave implements Explorar{
    private static final int MAX_CARGA = 500;
    private static final int MIN_CARGA = 100;

    private double capacidadCarga;

    public Carguero( String nombre, int capacidad, int anioLanzamiento,double capacidadCarga) {
        super(nombre, capacidad, anioLanzamiento);
        if(capacidadCarga < MIN_CARGA || capacidadCarga > MAX_CARGA){
            throw new IllegalArgumentException("La capacidad de carga de la nave carguera debe estar entre " + MAX_CARGA + " y " + MIN_CARGA + " tns.");
        }
        this.capacidadCarga = capacidadCarga;
    }
    
    @Override
    public void explorar() {
        System.out.println("Explorando con la Nave carguera " + getNombre());
    }
        
    @Override
    public String toString(){
        return super.toString() + " Capacidad de carga: " + capacidadCarga + " toneladas";
    }
}
