
package expedicionesespaciales;


public class NaveRepetidaException extends RuntimeException {
    private static final String MESSAGE = "Esta nave ya existe!";

    public NaveRepetidaException() {
        super(MESSAGE);
    }
}
