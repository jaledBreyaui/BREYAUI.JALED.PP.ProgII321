package expedicionesespaciales;


public class ExpedicionesEspaciales {


    public static void main(String[] args) {
        Agencia agencia = new Agencia();
        
//        Argumento invalido en Nave Carguera
//        try {
//            agencia.agregarNave(new NaveExploracion("Wanchope", 100, 2024, TipoMision.CARTOGRAFIA));
//            agencia.agregarNave(new CruceroEstelar("Interestelar", 100, 2024, 100));
//            agencia.agregarNave(new Carguero("Galactica", 100, 2024, 300));
//        } catch (NullPointerException | NaveRepetidaException | IllegalArgumentException  e) {
//            System.out.println(e.getMessage());
//        }

        

//        Nave repetida

        try {
            agencia.agregarNave(new Carguero("Galactica", 100, 2024, 300));
            agencia.agregarNave(new NaveExploracion("Wanchope", 100, 2024, TipoMision.CARTOGRAFIA));
            agencia.agregarNave(new CruceroEstelar("Interestelar", 100, 2024, 100));
            agencia.agregarNave(new Carguero("Galactica", 100, 2024, 300));
        } catch (NullPointerException | NaveRepetidaException | IllegalArgumentException  e) {
            System.out.println(e.getMessage());
        }


//        Argumento invalido en Nave Carguera

//        try {
//            agencia.agregarNave(new NaveExploracion("Wanchope", 100, 2024, TipoMision.CARTOGRAFIA));
//            agencia.agregarNave(new CruceroEstelar("Interestelar", 100, 2024, 100));
//            agencia.agregarNave(new Carguero("Galactica", 100, 2024, 1000));
//        } catch (NullPointerException | NaveRepetidaException | IllegalArgumentException  e) {
//            System.out.println(e.getMessage());
//        }


//        Argumento invalido en Crucero Estelar

//        try {
//            agencia.agregarNave(new NaveExploracion("Wanchope", 100, 2024, TipoMision.CARTOGRAFIA));
//            agencia.agregarNave(new CruceroEstelar("Interestelar", 100, 2024, 0));
//            agencia.agregarNave(new Carguero("Galactica", 100, 2024, 500));
//        } catch (NullPointerException | NaveRepetidaException | IllegalArgumentException  e) {
//            System.out.println(e.getMessage());
//        }
//        
        

        System.out.println("Naves de la agencia:");
        agencia.mostrarNaves();
        System.out.println("------------------");
        System.out.println("Inicio de exploracion");
        agencia.iniciarExploracion();
        
        
    }
    
}
