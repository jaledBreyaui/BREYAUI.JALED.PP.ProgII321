
package expedicionesespaciales;

import java.util.List;
import java.util.ArrayList;

public class Agencia {
    private List<Nave> naves;

    public Agencia() {
       this.naves = new ArrayList<>();
    }
    
    public void agregarNave(Nave nave){
        if (nave == null){
            throw new NullPointerException("Argumento nulo");
        }
        
        if(!naveRepetida(nave)){
            naves.add(nave);            
        }
    }
    
    private boolean naveRepetida (Nave nave){
        if(naves.contains(nave)){
            throw new NaveRepetidaException();
        }
        return false;
    }
    
    public void mostrarNaves(){
        for(Nave n : naves){
            System.out.println(n);
        }
    }
    
    public void iniciarExploracion(){
        for(Nave nave: naves){
          if(nave instanceof Explorar explorar){
              explorar.explorar();
          }
          else{
              System.out.println("La nave " + nave.getNombre()+ " no puede explorar" );
          }
      }
    }
}
