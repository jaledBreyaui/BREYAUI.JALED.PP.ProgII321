
package expedicionesespaciales;

public class CruceroEstelar extends Nave{
    private int cantidadPasajeros;

    public CruceroEstelar(String nombre, int capacidad, int anioLanzamiento, int cantidadPasajeros) {
        super(nombre, capacidad, anioLanzamiento);
        if(cantidadPasajeros < 1){
            throw new IllegalArgumentException("La cantidad de pasajeros del crucero estelar debe ser mayor a 0");
        }
        this.cantidadPasajeros = cantidadPasajeros;
    }
    
    @Override
    public String toString(){
        return super.toString() + " Cantidad de pasajeros: " + cantidadPasajeros;
    }
}
