
package expedicionesespaciales;

public interface Explorar {
    void explorar();
}
